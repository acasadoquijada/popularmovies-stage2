# Popular Movies Stage 2

## General Overview

This repo contains all the work done for the **Popular Movies Stage 2** project of the Udacity's Android Developer Nanodegree.

## Application description

TODO
	
## Application class structure

    |-- activities package
    |   |-- DetailActivity.java
    |   |-- MainActivity.java
    |-- movie package
    |   |-- Movie.java
    |   |-- MovieAdapter.java
    |-- utilities package
    |   |-- JsonMovieUtils.java
    |   |-- NetworkUtils.java
    
TODO: Add an small description of each package/class
